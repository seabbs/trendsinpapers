message("|", getwd(), "|")
