## Test environments

* local OS X install, R 3.4.1
* ubuntu 12.04 (on travis-ci), R 3.4.1
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 1 notes

### Notes

* Possibly misspelled word "destructuring" in DESCRIPTION is intentionally used.

## Reverse dependencies

There are no reverse dependencies.
